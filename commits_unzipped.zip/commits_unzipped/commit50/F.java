public class F extends null {

    int af();

    int hh();

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public long ac() {
        return 222;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public double ad() {
        return 11;
    }
}
