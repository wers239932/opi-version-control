public class F extends null {

    int af();

    int hh();

    public String kk() {
        return "No";
    }

    public Object gg() {
        return new java.util.Random();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void ab() {
        System.out.println();
    }

    public int cc() {
        return 39;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
