public class A extends null {

    void ab();

    float ff();

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
