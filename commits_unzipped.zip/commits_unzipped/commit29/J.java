public class J implements F, A {

    private byte c = 1;

    private byte d = 1;

    public void aa() {
        return;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int af() {
        return -1;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        System.out.println("\n");
    }

    public float ff() {
        return 3.14;
    }

    public int cc() {
        return 39;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public String kk() {
        return "Hello world";
    }

    public byte oo() {
        return 1;
    }
}
