public class F extends null {

    int af();

    int hh();

    public float ff() {
        return 0;
    }

    public double ee() {
        return 100.500;
    }
}
