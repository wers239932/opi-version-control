public interface A {

    void ab();

    float ff();
}
