public class K extends null implements F, A {

    private int e = 42;

    private long c = 4321;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public byte oo() {
        return 3;
    }

    public int af() {
        return -1;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        System.out.println();
    }

    public float ff() {
        return 0;
    }

    public void bb() {
        System.out.println(42);
    }

    public long dd() {
        return 33;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ad() {
        return 9.11;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object pp() {
        return this;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public long ac() {
        return 222;
    }

    public String kk() {
        return "Hello world";
    }

    public Object rr() {
        return null;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
