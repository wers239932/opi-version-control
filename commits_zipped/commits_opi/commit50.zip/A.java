public class A extends null {

    void ab();

    float ff();

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public double ee() {
        return 500.100;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
