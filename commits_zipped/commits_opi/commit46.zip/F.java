public class F extends null {

    int af();

    int hh();
}
