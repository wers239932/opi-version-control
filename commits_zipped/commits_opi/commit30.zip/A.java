public class A extends null {

    void ab();

    float ff();

    public double ee() {
        return java.lang.Math.PI;
    }

    public long dd() {
        return 33;
    }
}
