public class F extends null {

    int af();

    int hh();

    public String kk() {
        return "No";
    }

    public Object gg() {
        return new java.util.Random();
    }
}
