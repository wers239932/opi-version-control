public interface F {

    int af();

    int hh();
}
