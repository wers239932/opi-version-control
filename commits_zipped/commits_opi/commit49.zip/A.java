public class A extends null {

    void ab();

    float ff();

    public void bb() {
        System.out.println(getClass().getName());
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public long dd() {
        return 33;
    }

    public int ae() {
        return 9;
    }

    public int cc() {
        return 39;
    }
}
