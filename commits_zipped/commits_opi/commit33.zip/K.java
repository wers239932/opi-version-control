public class K extends null implements F, A {

    private int e = 42;

    private long c = 4321;

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public byte oo() {
        return 3;
    }

    public int af() {
        return -1;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        System.out.println();
    }

    public float ff() {
        return 0;
    }

    public void bb() {
        System.out.println(42);
    }

    public long dd() {
        return 33;
    }

    public void aa() {
        return;
    }

    public int cc() {
        return 13;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public double ad() {
        return 9.11;
    }
}
