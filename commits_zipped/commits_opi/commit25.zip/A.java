public class A extends null {

    void ab();

    float ff();
}
